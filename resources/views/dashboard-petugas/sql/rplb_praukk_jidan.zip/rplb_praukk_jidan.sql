-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2021 at 01:22 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rplb_praukk_jidan`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_log`
--

CREATE TABLE `activity_log` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `log_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject_id` bigint(20) UNSIGNED DEFAULT NULL,
  `causer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` bigint(20) UNSIGNED DEFAULT NULL,
  `properties` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_log`
--

INSERT INTO `activity_log` (`id`, `log_name`, `description`, `subject_type`, `subject_id`, `causer_type`, `causer_id`, `properties`, `created_at`, `updated_at`) VALUES
(1, 'menu', 'Zidan Indratama has been created menu', 'App\\Menu', 1, 'App\\User', 1, '{\"attributes\":{\"name\":\"Menu 1\",\"price\":45000,\"status\":\"Tersedia\"}}', '2021-03-30 16:05:25', '2021-03-30 16:05:25'),
(2, 'menu', 'Zidan Indratama has been created menu', 'App\\Menu', 2, 'App\\User', 1, '{\"attributes\":{\"name\":\"Menu 2\",\"price\":33000,\"status\":\"Tersedia\"}}', '2021-03-30 16:05:58', '2021-03-30 16:05:58'),
(3, 'menu', 'Zidan Indratama has been created menu', 'App\\Menu', 3, 'App\\User', 1, '{\"attributes\":{\"name\":\"Menu 3\",\"price\":55000,\"status\":\"Tersedia\"}}', '2021-03-30 16:06:27', '2021-03-30 16:06:27'),
(4, 'menu', 'Zidan Indratama has been created menu', 'App\\Menu', 4, 'App\\User', 1, '{\"attributes\":{\"name\":\"Menu 4\",\"price\":32000,\"status\":\"Tersedia\"}}', '2021-03-30 16:06:59', '2021-03-30 16:06:59'),
(5, 'menu', 'Zidan Indratama has been created menu', 'App\\Menu', 5, 'App\\User', 1, '{\"attributes\":{\"name\":\"Black Meat Monsta Cruncheeze\",\"price\":110000,\"status\":\"Tersedia\"}}', '2021-03-30 16:07:30', '2021-03-30 16:07:30'),
(6, 'menu', 'Zidan Indratama has been created menu', 'App\\Menu', 6, 'App\\User', 1, '{\"attributes\":{\"name\":\"Cheese Lovers\",\"price\":133000,\"status\":\"Tersedia\"}}', '2021-03-30 16:07:58', '2021-03-30 16:07:58'),
(7, 'menu', 'Zidan Indratama has been created menu', 'App\\Menu', 7, 'App\\User', 1, '{\"attributes\":{\"name\":\"Pepperoni Pizza\",\"price\":125000,\"status\":\"Tersedia\"}}', '2021-03-30 16:08:31', '2021-03-30 16:08:31'),
(8, 'menu', 'Zidan Indratama has been created menu', 'App\\Menu', 8, 'App\\User', 1, '{\"attributes\":{\"name\":\"Lasagna\",\"price\":65000,\"status\":\"Tersedia\"}}', '2021-03-30 16:08:57', '2021-03-30 16:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `deskripsi` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gambar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `price`, `deskripsi`, `status`, `gambar`, `created_at`, `updated_at`) VALUES
(1, 'Menu 1', 45000, '<p>Kelezatan Ayam Krispy WarungKita kami berasal dari daging ayam halal yang terjaga kesegarannya, yaitu: bebas dari antibiotik serta tidak disuntik hormon. Kami mengolah daging ayam menggunakan tepung berkualitas dan bumbu alami tanpa pengawet maupun pewarna buatan. Agar bumbu meresap sempurna, daging ayam dipijat sekaligus dibalut dengan tepung, kemudian direndam ke dalam air dingin. Proses ini dilakukan sebanyak 2x sebelum ayam digoreng menggunakan minyak sawit berkualitas dan bersertifikat RSPO (Roundtable on Sustainable Palm Oil) dengan suhu yang telah ditentukan, sehingga tercipta tekstur yang empuk di dalam dan renyah di luar.</p>', 'Tersedia', 'warung_kita/assets/img/uploads/1617145524menu 1.png', '2021-03-30 16:05:24', '2021-03-30 16:05:24'),
(2, 'Menu 2', 33000, '<p>Bumbu Ayam Spicy WarungKita hanya terbuat dari bahan alami, seperti paprika dan bubuk cabai. Agar bumbu dapat meresap sempurna, kami menggunakan mesin marinasi dengan tekanan, temperatur, dan waktu yang sudah ditentukan. Setelah daging ayam dimarinasi, potongan daging ayam kemudian dibalut dengan tepung pedas spesial WarungKita .</p>', 'Tersedia', 'warung_kita/assets/img/uploads/1617145557menu 2.png', '2021-03-30 16:05:57', '2021-03-30 16:05:57'),
(3, 'Menu 3', 55000, '<p>Karena kami menggunakan 100% daging sapi halal tanpa bahan tambahan lainnya seperti tepung, pengawet, dan pewarna. Untuk menciptakan daging burger lezat, kami membumbui daging dengan sedikit garam serta lada, kemudian daging dipanggang sempurna tanpa menggunakan minyak. Bukan hanya itu, daging burger pun hanya disajikan saat dipesan&nbsp;<em>(Made For You),</em>&nbsp;tidak pernah ada yang dipanaskan ulang.</p>', 'Tersedia', 'warung_kita/assets/img/uploads/1617145587menu 3.png', '2021-03-30 16:06:27', '2021-03-30 16:06:27'),
(4, 'Menu 4', 32000, '<p>Kami menggunakan 100 % kentang asli yang telah digoreng dalam keadaan setengah matang sebelum dibekukan dan diantar ke restoran WarungKita. Saat dipesan oleh pelanggan, kentang akan digoreng sempurna menggunakan minyak sawit berkualitas dan bersertifikat RSPO (<em>Roundtable on Sustainable Palm Oil)</em>, kemudian diberi taburan garam. Untuk menjaga tekstur yang empuk di bagian dalam dan renyah di bagian luar, French Fries disajikan tidak lebih dari 7 menit setelah digoreng</p>\r\n\r\n<p>&nbsp;</p>', 'Tersedia', 'warung_kita/assets/img/uploads/1617145619menu 4.png', '2021-03-30 16:06:59', '2021-03-30 16:06:59'),
(5, 'Black Meat Monsta Cruncheeze', 110000, '<p>Nikmati kelembutan pizza dengan roti hitam dipadu dengan topping Sosis frankfurter, daging sapi asap, daging sapi cincang, jamur, keju mozzarella, saus keju dan beef bits. Berpadu dengan renyahnya cruncheeze di pinggiran pizza. Tersedia ukuran Regular &amp; Large.</p>', 'Tersedia', 'warung_kita/assets/img/uploads/1617145650black meat monsta.png', '2021-03-30 16:07:30', '2021-03-30 16:07:30'),
(6, 'Cheese Lovers', 133000, '<p>cheese pizza adalah salah satu jenis pizza yang paling populer. Bahkan setiap 5 Septermber, diperingati sebagai hari pizza keju sedunia (Cheese Pizza Day).&nbsp;</p>', 'Tersedia', 'warung_kita/assets/img/uploads/1617145678cheese lovers.png', '2021-03-30 16:07:58', '2021-03-30 16:07:58'),
(7, 'Pepperoni Pizza', 125000, '<p>Pepperoni adalah bumbu salami yang berasal dari Amerika Serikat-Italia, terbuat dari daging babi dan sapi. Di Italia, pepperoni disebut salame piccante (salami panas). Biasa menjadi bahan baku pizza di Amerika Serikat, yang sering mewakili 30% pelengkap.</p>\r\n\r\n<p>&nbsp;</p>', 'Tersedia', 'warung_kita/assets/img/uploads/1617145711pepperoni.png', '2021-03-30 16:08:31', '2021-03-30 16:08:31'),
(8, 'Lasagna', 65000, '<p>Lasagna atau Lasagne adalah pasta yang dipanggang di oven dan merupakan makanan tradisional Italia. Lasagna sendiri secara harfiah adalah lasagne yang berisikan daging. Lasagna sendiri dapat diisi dengan banyak isian lainnya seperti daging, sayur-sayuran, ayam, makanan laut dan sebagainya sesuai selera.</p>', 'Tersedia', 'warung_kita/assets/img/uploads/1617145737lasagna.png', '2021-03-30 16:08:57', '2021-03-30 16:08:57');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(17, '2014_10_12_000000_create_users_table', 1),
(18, '2014_10_12_100000_create_password_resets_table', 1),
(19, '2019_08_19_000000_create_failed_jobs_table', 1),
(20, '2021_03_01_023126_create_menus_table', 1),
(21, '2021_03_02_024900_create_orders_table', 1),
(22, '2021_03_04_001045_create_activity_log_table', 1),
(23, '2021_03_04_102529_create_order_items_table', 1),
(24, '2021_03_06_041734_create_payments_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_meja` int(11) NOT NULL,
  `keterangan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` datetime NOT NULL,
  `payment_due` datetime NOT NULL,
  `payment_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_total_price` decimal(16,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `tax_percent` decimal(16,2) NOT NULL DEFAULT 0.00,
  `payment_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grand_total` decimal(16,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(10) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `menu_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `base_price` decimal(16,2) NOT NULL DEFAULT 0.00,
  `base_total` decimal(16,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `tax_percent` decimal(16,2) NOT NULL DEFAULT 0.00,
  `sub_total` decimal(16,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` int(10) UNSIGNED NOT NULL,
  `number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(16,2) NOT NULL DEFAULT 0.00,
  `method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payloads` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payloads`)),
  `payment_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `va_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vendor_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `biller_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bill_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gambar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Pelanggan',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `gambar`, `role`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Zidan Indratama', 'zidanindratama', NULL, 'Administrator', 'zidanindratama@gmail.com', NULL, '$2y$10$VsOLnNIrQtcGSfJ2e8ZcaONHBWpKCzSv.F7BP1HyiRJtVGxuMiY3K', NULL, '2021-03-30 15:44:37', '2021-03-30 15:44:37'),
(2, 'Owner', 'owner', NULL, 'Owner', 'owner@gmail.com', NULL, '$2y$10$TGO5fAYyNvXyZi4djF3G3uD5AKnFsV4K8N3H.AVFd6u3YI/QTr.ye', NULL, '2021-03-30 15:44:37', '2021-03-30 15:44:37'),
(3, 'kasir', 'kasir', NULL, 'Kasir', 'kasir@gmail.com', NULL, '$2y$10$CyvPw/NoS168hA9eHdi.uuxKMTi1YMr2exnZf6L40ztmCz3rYFk/2', NULL, '2021-03-30 15:44:38', '2021-03-30 15:44:38'),
(4, 'waiter', 'waiter', NULL, 'Waiter', 'waiter@gmail.com', NULL, '$2y$10$q2e43QG9/9WcOYgQ4a9id.oYYJnUkiYZTuiMHpcZucmQbcq72MO3q', NULL, '2021-03-30 15:44:38', '2021-03-30 15:44:38'),
(5, 'pelanggan', 'pelanggan', NULL, 'Pelanggan', 'pelanggan@gmail.com', NULL, '$2y$10$xKelUonippqxm92FwjDRkuJaXS69E0Sl.SKk7nEv4uPWmU4LhCqqm', NULL, '2021-03-30 15:44:38', '2021-03-30 15:44:38');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_log`
--
ALTER TABLE `activity_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject` (`subject_type`,`subject_id`),
  ADD KEY `causer` (`causer_type`,`causer_id`),
  ADD KEY `activity_log_log_name_index` (`log_name`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `orders_code_unique` (`code`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`),
  ADD KEY `order_items_menu_id_foreign` (`menu_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payments_number_unique` (`number`),
  ADD KEY `payments_order_id_foreign` (`order_id`),
  ADD KEY `payments_number_index` (`number`),
  ADD KEY `payments_method_index` (`method`),
  ADD KEY `payments_token_index` (`token`),
  ADD KEY `payments_payment_type_index` (`payment_type`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_log`
--
ALTER TABLE `activity_log`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_menu_id_foreign` FOREIGN KEY (`menu_id`) REFERENCES `menus` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
